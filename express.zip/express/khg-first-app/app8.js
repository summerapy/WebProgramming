const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const static = require('serve-static');

const app = express(); // app 객체 선언 위치 수정

// body-parser 설정
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// 정적 파일 제공
app.use('/', static(path.join(__dirname, 'public')));

// 요청 처리
app.use(function(req, res, next) {
    const paramId = req.body.id || req.query.id;
    const paramPassword = req.body.password || req.query.password;

    res.status(200).send(
        `<h1>서버에서 응답한 결과</h1>
        <div><p>Param id : ${paramId}</p></div>
        <div><p>Param password : ${paramPassword}</p></div>
        <br><br><a href="/login1.html">로그인 페이지로 돌아가기</a>`
    );
});

// 서버 실행
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
